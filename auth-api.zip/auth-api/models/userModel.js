const users = [];

module.exports = users;