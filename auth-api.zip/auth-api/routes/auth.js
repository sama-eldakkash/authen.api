const express = require('express');
const router = express.Router();
const { register, login } = require('../controllers/authController');
const authenticate = require('../middleware/authMiddleware');
const authorize = require('../middleware/roleMiddleware');

router.post('/register', register);
router.post('/login', login);

router.get('/public', (req, res) => res.send('Public route'));
router.get('/protected', authenticate, (req, res) => res.send('Authenticated route'));
router.get('/moderator', authenticate, authorize(['moderator', 'admin']), (req, res) => res.send('Moderator route'));
router.get('/admin', authenticate, authorize(['admin']), (req, res) => res.send('Admin route'));


router.get('/profile', authenticate, (req, res) => {
    res.json({ user: req.user });
  });
  
  router.put('/profile', authenticate, (req, res) => {
    const { email, password } = req.body;
    const users = require('../models/userModel').getAllUsers();
    const userIndex = users.findIndex(u => u.id === req.user.id);
    if (userIndex === -1) return res.status(404).json({ message: 'User not found' });
  
    if (email) users[userIndex].email = email;
    if (password) users[userIndex].password = bcrypt.hashSync(password, 10);
  
    require('../models/userModel').saveUsers(users);
    res.json({ message: 'Profile updated' });
  });
  
  router.put('/users/:id/role', authenticate, authorize('admin'), (req, res) => {
    const { id } = req.params;
    const { role } = req.body;
    const users = require('../models/userModel').getAllUsers();
    const userIndex = users.findIndex(u => u.id === id);
    if (userIndex === -1) return res.status(404).json({ message: 'User not found' });
  
    users[userIndex].role = role;
    require('../models/userModel').saveUsers(users);
    res.json({ message: 'User role updated' });
  });
  
  module.exports = router;