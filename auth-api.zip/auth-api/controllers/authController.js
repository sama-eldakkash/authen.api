const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const users = require('../models/userModel');

const register = (req, res) => {
  const { username, email, password, role } = req.body;
  const emailRegex = /\S+@\S+\.\S+/;
  const passRegex = /^(?=.*\d)(?=.*[!@#$%^&*]).{8,}$/;

  if (!emailRegex.test(email) || !passRegex.test(password))
    return res.status(400).json({ msg: 'Invalid email or weak password' });

  const hashed = bcrypt.hashSync(password, 10);
  users.push({ id: users.length + 1, username, email, password: hashed, role });

  res.status(201).json({ msg: 'User registered' });
};

const login = (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ msg: 'Invalid credentials' });

  const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
  res.json({ token });
};

module.exports = { register, login };